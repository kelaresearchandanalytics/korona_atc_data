#' @importFrom glue glue
#' @importFrom haven read_dta
#' @importFrom haven read_sav
#' @importFrom readxl read_excel
#' @importFrom utils download.file
#' @importFrom utils read.csv
.QogEnv <- new.env()